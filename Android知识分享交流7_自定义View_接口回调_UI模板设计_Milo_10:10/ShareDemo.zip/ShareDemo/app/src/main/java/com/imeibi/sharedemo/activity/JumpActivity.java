package com.imeibi.sharedemo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.imeibi.sharedemo.R;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by milo on 15/9/7.
 * 页面跳转Activity
 */
public class JumpActivity extends Activity {
    @InjectView(R.id.back_btn)
    TextView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_layout);
        ButterKnife.inject(this);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.activity_left_in, R.anim.activity_right_out);
            }
        });
    }
}