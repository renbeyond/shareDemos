package com.example.sharedemoanimation;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivity extends Activity implements OnClickListener{
	private Button animationButton, animationObjectButton, nineOldButton;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        animationButton = (Button) findViewById(R.id.animation_btn);
        animationObjectButton = (Button) findViewById(R.id.animation_object_btn);
        nineOldButton = (Button) findViewById(R.id.nineold_btn);
        
        animationButton.setOnClickListener(this);
        animationObjectButton.setOnClickListener(this);
        nineOldButton.setOnClickListener(this);
        
    }

	@Override
	public void onClick(View v) {
		Intent intent = new Intent();
		
		switch (v.getId()) {
		case R.id.animation_btn:
			intent.setClass(MainActivity.this, AnimationActivity.class);
			break;
			
		case R.id.animation_object_btn:
			intent.setClass(MainActivity.this, ObjectAnimatorActivity.class);
			break;
			
		case R.id.nineold_btn:
			intent.setClass(MainActivity.this, GIFActivity.class);
			break;

		default:
			break;
		}
		startActivity(intent);
		
	}


}
