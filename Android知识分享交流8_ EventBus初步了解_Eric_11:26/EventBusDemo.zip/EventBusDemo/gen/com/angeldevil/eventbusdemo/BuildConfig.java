/** Automatically generated file. DO NOT MODIFY */
package com.angeldevil.eventbusdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}